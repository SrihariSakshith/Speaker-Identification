-------------------------------------------
Installation
-------------------------------------------
Run the following command: (If running on local environment)

python -m pip install numpy pandas matplotlib librosa shutil scikit-learn seaborn tensorflow keras ipython kaggle

-------------------------------------------
Dataset
-------------------------------------------
Dataset link: https://www.kaggle.com/datasets/kongaevans/speaker-recognition-dataset

Store the zip file in the same directory as "16000_pcm_speeches.zip".

In case of using google colab, Please store it in the session storage ( Prefix all the paths in the code with /content/ if using Google Colab)

Recommended environment: ***Jupyter Notebook***

Start executing the cells one by one.

-------------------------------------------
Documentation and Process
-------------------------------------------
We create a dataset of speech samples from various speakers, using the speaker as the label. 
To augment the data, we add background noise to these samples. 
We then apply the FFT to the noisy speech samples. 
Finally, we train a 1D convolutional neural network to predict the correct speaker based on the noisy FFT representation of the speech.